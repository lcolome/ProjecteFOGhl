# Configuració de servidor FOG
## Tria d'opcions de l'arxiu installfog.sh

A continuació, haurem de trar les següents opcións d'aquestes preguntes:

1. What version of Linux would you like to run the installation for? `2`

![La imatge no carrega](imatges/config1.jpg)

2. What type of installation woult you like to do? `n`
3. Would you like to change the default network interface from enp0s3? `n`
4. Would you like to setup a router address for the DHCP server? `n`
5. Would you like to DHCP to handle DNS? `y`
6. What DNS address should DHCP allow? `127.0.0.1`
7. Would you like to use the FOG server for DHCP service? `y`
8. This version of FOG has internationalization support, would you like to install the additional language pack? `y`
9. Would you like to enable secure HTTPS on your FOG server? `n`
10. Are you ok with sending this information? `y`

![La imatge no carrega](imatges/config2.jpg)

## Configuració de les DNS

Per a configurar les DNS, primer haurem de parar el servei systemd-resolved

`sudo systemctl stop systemd-resolved`

Eliminarem l'arxiu resolv.conf

`rm /etc/resolv.conf`

El tornarem a crear amb la comanda echo

`echo "nameserver 8.8.8.8" > /etc/resolv.conf`

Ara instal.larem el paquet dnsmasq

`sudo apt-get install dnsmasq`

![La imatge no carrega](imatges/config3.jpg)

Haurem d'editar l'arxiu de configuració

`gedit /etc/dnsmasq.d/ltsp.conf`

![La imatge no carrega](imatges/config4.jpg)

Aquí haurem de copiar les següents linies, canviant les IP per les de la nostra màquina i el rang del DHCP:

`port = 0`  
`log-dhcp`  
`tftp-root=/tftpboot`  
`dhcp-no-override`  
`dhcp-boot=undionly.kpxe,10.0.2.25`  
`pxe=prompt="Servidor FOG :)", 1`  
`dhcp-range=10.0.2.25,proxy`  

![La imatge no carrega](imatges/config5.jpg)

Per últim, reiniciarem el servei *dnmasq*

`sudo service dnsmasq restart`

![La imatge no carrega](imatges/restartMasq.jpg)

Un cop fet aixó, ja podrem entrar al servidor fog, obrint una pestanya del navegador i escrivint la ip del servidor o utilitzant localhost seguit de /fog .

![La imatge no carrega](imatges/confFinal.jpg)

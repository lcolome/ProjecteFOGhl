# Programari abans de la instal.lació

Per instal.lar programari des del servidor FOG, primer haurem d'instal.lar el client de FOG a cada PC. Per a fer-ho, ens baixarem el paquet que és troba a [github.com](https://github.com/FOGProject/fog-client/releases/download/0.13.0/SmartInstaller.exe)

Un cop instal.lat, executarem el setup i acceptarem els termes i condicions de l'aplicació.

![La imatge no carrega](imatges/setupw.jpg)

Al final de l'instal.lació, ens mostrarà un petit formultari ons haurem de posar la següent informació:

- **Server Address**: La IP del servidord FOG  
- **Web root**: /fog , que és la ruta predeterminada  
- Habilitar les opcions *Enable FOG Tray* i *Put log in filesystem root*
- Deshabilitar l'opció *Use HTTPS to connect to FOG server*

![La imatge no carrega](imatges/setupw2.jpg)

Fet aixó, instal.larem el programa on nosaltres vulguem i tanquem el setup.

# Preparar el servidor

Haurem d'anar a la màquina que té el servidor FOG i haurem de descarregar un paquet que nosaltres vulguem, en el nostre cas ens baixarem el Libreoffice. Un cop descarregat, anirem al servidor, al apartat de Snapin i en crearem un de nou.

En aquest apartat, haurem d'indicar:

- **Snapin Name**: El nom del paquet que enviarem.  
- **Snapin Description**: Descripció del paquet.  
- **Snapin Group**: El deixem per defecte.  
- **Snapin Type**: El deixem per defecte.  
- **Snapin Template**: En el nostre cas, com el paquet és un .msi, triarem la plantilla de MSI.  
- **Snapin Run With**: El deixarem per defecte.  
- **Snapin file**: Serà on triarem el paquet descarregat.  
- Els altres paràmetres els deixarem per defecte, menys **Reboot after install**, que l'activarem

![La imatge no carrega](imatges/snapinConf.jpg)
![La imatge no carrega](imatges/snapinConf2.jpg)

Ara, ens dirigirem al apartat de Basic tasks, i el que farem serà crear una tasca avançada.

![La imatge no carrega](imatges/taskAdvanced.jpg)

Aquí, triarem el desplegable de snapin i seleccionarem **Single Snapin**, ja que sol volem llençar un paquet.

![La imatge no carrega](imatges/singleSnapin.jpg)

Ens sortirà una finestra per a confirmar la tasca i triar el snapin. Marquarem que ho volem fer inmediatament i acceptarem la tasca.

![La imatge no carrega](imatges/confirmarTask.jpg)
![La imatge no carrega](imatges/confirmarTask2.jpg)  
*Tasca creada correctament*  

Un cop creada, si reiniciem el client de Windows, veurem que al centre de notificacions ens està dient que estem instal.lant l'aplicació de Libreoffice. També s'obrra el FOG client, mostrant la barra de progrés de la instal.lació.

![La imatge no carrega](imatges/confirmarPaquet.jpg)
![La imatge no carrega](imatges/confirmarPaquet2.jpg)

#Comprovacions

Tenim dues maneres de comprovar la correcta instal.lació:

1. **Anar al servidor**: A la pestanya de Snapin History veurem que un host ha utilitzat el snapin.

![La imatge no carrega](imatges/compSnapin.jpg)

2. **Client**: Sol cal mirar al client que tingui instal.lat el paquet, un cop reiniciat.

![La imatge no carrega](imatges/compSnapin2.jpg)


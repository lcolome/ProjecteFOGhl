# Preparació  dels paquets

El primer pas serà descarregar un paquet, el que nosaltres vulguem, dintre del servidor. En el nostre cas serà el team viewer, que el podrmes descarregar a 

[teamviewer.com](https://download.teamviewer.com/download/linux/teamviewer_amd64.deb)

Fet aixó, haurem de moure el paquet .deb que s'ens ha baixat al directori `/var/www/html/fog`

![La imatge no carrega](imatges/moureteam.jpg)

Ara crearem un script, que li direm *instalar.sh*, que executara la instal.lació del paquet. Hem de tenir en compte que les dades del paquet i la contrasenya canvien segons el paquet o la contrasenya de sudo:

`!/bin/bash`  
`sudoPassword=Admin123`  
`cd /tmp`  
`wget http://10.0.2.15/fog/teamviewer_15.41.7`  
`echo $sudoPassword | sudo -S dpkg -i teamviewer_15.41.7_amd64.deb`  

![La imatge no carrega](imatges/scriptInstall.jpg)

Ara, executarem les següents comandes per instalar *mono*:

1. `sudo apt install gnupg ca-certificates`  
2. `sudo gpg --homedir /tmp --no-default-keyring --keyring /usr/share/keyrings/mono-official-archive-keyring.gpg --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys 3FA7E0328081BFF6A14DA29AA6A19B38D3D831EF`  
3. `echo "deb [signed-by=/usr/share/keyrings/mono-official-archive-keyring.gpg] https://download.mono-project.com/repo/ubuntu stable-focal main" | sudo tee /etc/apt/sources.list.d/mono-official-stable.list`  
4. `sudo apt update`  
5. `sudo apt install mono-complete`   

Amb l'aplicació *mono* instal.lada, haurem de instal.lar l'aplicació *SmartInstaller.exe*, que haurem de descarregar previament des de [github.com](https://github.com/FOGProject/fog-client/releases/download/0.13.0/SmartInstaller.exe).

`sudo mono SmartInstaller.exe`

Feta aquesta comanda, ens demanarà la IP del fog server, que en el nostre cas serà **10.0.2.25**. La resta d'opcions clicarem *Enter* per a deixar-ho per defecte.

![La imatge no carrega](imatges/smartinstaller.jpg)

Passats uns segons, veurem que la instal.lació s'ha completat correctament.

![La imatge no carrega](imatges/smartinstallerOK.jpg)

# Creació del Snapin

Fet això, anirem al servidor FOG i crearem un nou snapin dintre del apartat *Snapin Management*. En aquest apartat, haurem d'indicar:

- **Snapin Name**: El nom del paquet que enviarem.
- **Snapin Description**: Descripció del paquet.
- **Snapin Group**: El deixem per defecte.
- **Snapin Type**: El deixem per defecte.
- **Snapin Template**: En el nostre cas, com el fitxer de instal.lació és el script que hem creat anteriorment, el tipus serà *Bash Script*
- **Snapin Run With**: El deixarem per defecte.
- **Snapin file**: Serà on carregaren el script.
- Els altres paràmetres els deixarem per defecte, menys Reboot after install, que l'activarem

![La imatge no carrega](imatges/snapinU.jpg)
![La imatge no carrega](imatges/snapinU2.jpg)

Ara, ens dirigirem al apartat de Basic tasks, i el que farem serà crear una tasca avançada.

![La imatge no carrega](imatges/taskAdvanced.jpg)

Aquí, triarem el desplegable de snapin i seleccionarem **Single Snapin**, ja que sol volem llençar un paquet.

![La imatge no carrega](imatges/singleSnapin.jpg)

Ens sortirà una finestra per a confirmar la tasca i triar el snapin. Marquarem que ho volem fer inmediatament i acceptarem la tasca.

![La imatge no carrega](imatges/confirmarTask3.jpg)
![La imatge no carrega](imatges/confirmarTask4.jpg)  
*Tasca creada correctament*  

Despres d'axió, sol caldrà reiniciar l'ubuntu client i ja s'instal.larà sol.

# Comprovació de la instal.lació dels paquets

Tenim dos mètodes per comprovar que el programa s'ha instal.lat correctament:

1. Dintre del servidor, *tenim l'apartat Host Snapin HIstory*, on ens mostrarà la informació del host que ha rebut un snapin correcrament, amb el nom del paquet, la data, la hora...

![La imatge no carrega](imatges/confirmarsnapin3.jpg)

2. Entrar al client i veure que el paquet que hem instal.lat és troba dintre del sistema, en el nostre cas TeamViewer.

![La imatge no carrega](imatges/confirmarsnapin4.jpg)

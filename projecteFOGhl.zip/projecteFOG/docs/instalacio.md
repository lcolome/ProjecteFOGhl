# Instal.lació de servidor FOG 
##Preparació del entorn

Per aquest projecte necessitarem

- Ubuntu 22.04, qué serà el servidor
- Ubuntu 20.04 o posterior, que serà el client
- Windows 10 o posterior, que també serà el client

Per começar, haurem de posar una IP fixa. També hem de tenir en compte que la DNS primaria haurà de ser la nostra IP.

![La imatge no carrega](imatges/ip.jpg)

##Descàrrega del paquet

Per a instal.lar el paquet, haurem d'anar al següent lloc: [fogproject.org](https://fogproject.org/download).

Seguint els passos de la pàgina, ens haurem de baixar el tar.gz. Seguidament, ens haurem de situar a la carpeta on s'ha desat i escriure les següents comandes:

`sudo -i`  
`tar xvzf fogproject-1.5.10.tar.gz`  
`cd fogproject-1.5.10/bin`  
`./installfog.sh`  

# Capturar des d'un client
## Creació d'imatges

Per a crear les imatges de Windows i Ubuntu, haurem d'anar al apartat d'imatges i triarem l'opció **create new image**. Aquést procés l'haurem de fer dues vegades, un per a Windows i l'altre per a Ubuntu.

Fet aixó, haurem de posar la informació als següents camps:

- **Image Name**: Serà el nom que li donarem a la imatge.  
- **Image Description**: Per a donar-li una descripció.  
- **Storage Group**: El deixarem per defecte.  
- **Operating System**: Triarem el sistema operatiu que serà instal.lat.  
- **Image Path**: El directori on desarem la imatge.  
- **Image Type**: És el tipus d'imatge, que el deixarem per defecte.  
- **Partition**: També el deixarem per defecte.  
- **Image Enable**: El deixarem actiu.  
- **Replicate**: Activarem aquesta casella.  
- **Compression**: El deixarem a 6.  
- **Image Manager**: És quedarà per defecte.  

Un cop fet aixó, Tocarem el botó **Add** per a confirmar i ja haurem creat les imatges

![La imatge no carrega](imatges/imatgewindows.jpeg) *Iso per a Windows*
![La imatge no carrega](imatges/imatgeUbuntu.jpg) *Iso per a Ubuntu*

## Preparació dels clients

Haurem de crear una màquina virtual amb les següents característiques:

- Des de Virtualbox, hem d'habilitar l'opició **xarxa** com a possible ordre d'arrancada
- Hem de posar l'opició xarxa per sobre de les demés.
- Els clients, al igual que el servidor FOG, ha d'estar en xarxa NAT.

## Registrar clients

Per registrar els clients caldrà obrir les màquines virtuals i pasat uns segons ens apareixerà la pantalla de FOG. Haurem de triar l'opció **Quick Registration And inventory** i mes tard apagar el client. Abans de registrar el client, podem instal.lar paquets per veure que és replica. En el nostre cas, hem instalat el navegador Opera i el Visual Studio. 

![La imatge no carrega](imatges/FOGregistre.jpg)

Fet aixó, al servidor ens apareixeràn els equips amb les seves adreçes MAC al llistat de hosts. Un cop registrats caldrà associar el client a la imatge creada. Per a fer-ho, primer hem de crear un host, donant-li els següents paràmetres:

- **Host Name**: El nom del host.  
- **Primary MAC**: La MAC del equip que volem enllaçar.  
- **Host image**: La iso que hem creat al apartat *Creació d'Imatges*.  

![La imatge no carrega](imatges/enllaçHost.jpg)

Després, haurem de crear la taska d'associació, indicant que volem utilitzar el paràmetre *Wake on LAN* i *Schedule instant* per a fer-ho al acte. Un cop triat aquestes opcións, tocarem el botó *Task* perque comenci.

![La imatge no carrega](imatges/enllaçConfirmar.jpg)
![La imatge no carrega](imatges/creaciotasca.jpg)

Al acceptar la tasca, iniciarem el client i automàticament començarà a fer la còpia del seu disc cap al servidor.

![La imatge no carrega](imatges/carregaWindows.jpg)  
*Captura d'una imatge Windows*
![La imatge no carrega](imatges/carregaUbuntu.jpg)  
*Captura d'una imatge Ubuntu*

Si els clients s'han creat correctament, ens apareixeran amb un tick verd

![La imatge no carrega](imatges/pujadacorrecta.jpg)

## Desplegar les imatges

Per posar les imatges a clients nous, al igual que amb les màquines amb les que hem generat les ISO, harem de:

- Des de Virtualbox, hem d'habilitar l'opició **xarxa** com a possible ordre d'arrancada
- Hem de posar l'opició xarxa per sobre de les demés.
- Els clients, al igual que el servidor FOG, ha d'estar en xarxa NAT.

Fet aixó, iniciarem la màquina i a la pestanya del FOG trialem l'opció *deploy image*

![La imatge no carrega](imatges/deployimage.jpg)

Iniciarem sessió al servidor FOG amb l'usuari i contrasenya que hem posat a l'hora d'instalar el servidor

![La imatge no carrega](imatges/sessio.jpg)

Si hem iniciat sessió correctament, ens apareixeran les dos possibles ISO de instal.lació. Triarem la que vulguem i, inalitzat la tria de la ISO, començarà a fer la instal.lació.

![La imatge no carrega](imatges/triaISO.jpg)  
*Tria d'imatge Windows*
![La imatge no carrega](imatges/triaISOu.jpg)  
*Tria d'imatge Ubuntu*
![La imatge no carrega](imatges/procesTria.jpg)  
*Procés d'instal.lacio de Windows*
![La imatge no carrega](imatges/procesTriau.jpg)  
*Procés d'instal.lacio d'Ubuntu*

## Comprovació de la instal.lació

Un cop finalitzat el procés de instal.lació, sol caldra obrir les màquines clients i veurem com és igual al primer client del qual hem fet la còpia. Si ens fixem, el client windows té els paquets de Opera i Visual Studio instal.lats, al igual que amb el client que hem creat la iso

![La imatge no carrega](imatges/compw.jpg)  
*Comprovació de la imatge amb Windows*
![La imatge no carrega](imatges/compu.jpg)  
*Comprovació de la imatge amb Ubuntu*
